from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    tag = models.CharField("Уникальный тег", max_length=30, unique=True, blank=True, null=True)
    avatar = models.ImageField("Аватарка", upload_to='avatars/', blank=True, null=True)
    age = models.PositiveIntegerField("Возраст", blank=True, null=True)
    bio = models.TextField("О себе", max_length=500, blank=True)

    def __str__(self):
        return f"Профиль {self.user.username}"

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance, tag=f"@{instance.username}")

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    if hasattr(instance, 'profile'):
        instance.profile.save()
